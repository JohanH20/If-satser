using System;

class MainClass {
  public static void Main (string[] args) {
   Console.Write("Skriv ett tal: ");
   int tal = int.Parse(Console.ReadLine());
    if(tal > 10)
      Console.WriteLine("Talet är större än 10");

    else if(tal < 10)
      Console.WriteLine("Talet är mindre än 10");
    else
      Console.WriteLine("Talet är 10");
  }
}
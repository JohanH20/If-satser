using System;

class MainClass {
  public static void Main (string[] args) {
  Console.Write("Är det fint väder?: ");
  string vader = Console.ReadLine();
  if(vader == "J" || vader== "j")
    Console.WriteLine("Vi går på picknick!");
            
  else if(vader == "N" || vader == "n")
    Console.WriteLine("Vi stannar inne och läser en bok");
    
  else
    Console.WriteLine("Jag förstår inte");
  
  }
}